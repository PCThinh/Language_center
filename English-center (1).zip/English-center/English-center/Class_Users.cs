﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace English_center
{
    internal class Class_Users
    {
        public string id { get; set; }   
        public string NameCourse { get; set; }
        public string Quantity { get; set; }
        public string TeacherName { get; set; }
        public string status { get; set; }
    }
}
